#include<stdio.h>

int main(){
	printf("nmsl");
}

